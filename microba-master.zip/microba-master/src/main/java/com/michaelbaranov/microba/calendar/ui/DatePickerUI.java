package com.michaelbaranov.microba.calendar.ui;

public abstract class DatePickerUI extends CalendarPaneUI {

	public abstract void showPopup(boolean visible);

	public abstract void setSimpeLook(boolean b);

}
