package com.michaelbaranov.microba.calendar.resource;

public class Resource {

}
